window.facets = {
    "facets":[],
    "collection":[],
    "sortBtns":[
  		{"field":"metaDateField","display":"Sort by date "},
      {"field":"relevance","display":" Sort by relevance"}
    ],
    "facetFiltersOrder":[
      "contenttype"
    ],
    "facetFiltersType": "OR",
    "sortDir":"desc",
    "matchAny":"off",
    "pageSize": "10",
    "defaultCname":"Intranet",
    "adsDisplay":"true",
    "adsCname":["Intranet"],
    "featuredResultsCount":"3",
    "showAutoSuggest": true,
     "metaDateField":"DC.date.reviewed",
     "metaDateFormat":"YYYY-MM-DD hh:mm:ss.ss",
     "relatedQuery":{"field":"true"},
  "relatedQueryFields":
    {"apikey":"","field":"title","operator":"or","limit":"5","terms":"10","type":"phrase","col":""}
  ,
    "dataToBeDisplayed": {
      "1": {
        "title" : "Title",
        "description" : "Description"
      },
      "other": {
        "description" : "Description"
      },
      "displayAll": true
    },
    "advancedFilters": {},
    "defaultType": "AND",
    "tune":  {
       "enable":"false",
       "tune.0": "3",
       "tune.1": "2",
       "tune.2": "2",
       "tune.3": "3",
       "tune.4": "180",
       "tune.5": "75"
    },
    "pluginDomain": ""
}
